
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'vishnufaith',
  applicationName: 'diagnalworkshop-app',
  appUid: 'Rx4QlS19gZJjvnZ6PV',
  orgUid: '6dd56428-880f-483c-b0e3-daed1d98f506',
  deploymentUid: '60272a30-8644-447b-9dce-dee22a284d73',
  serviceName: 'diagnalworkshop',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.15',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'diagnalworkshop-dev-OgpDetails', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}